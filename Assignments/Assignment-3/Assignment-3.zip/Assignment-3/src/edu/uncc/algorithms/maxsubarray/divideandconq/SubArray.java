package edu.uncc.algorithms.maxsubarray.divideandconq;

/**
 * @author venky on 2019-02-19
 * @project Assignment-3
 * @package edu.uncc.algorithms.maxsubarray.divideandconq
 */

/**
 * POJO class represents a sub array with start and end index and sum of sum array
 */
public class SubArray {

    private int lowIndex;
    private int highIndex;
    private int sum;

    public int getLowIndex() {
        return lowIndex;
    }

    public void setLowIndex(int lowIndex) {
        this.lowIndex = lowIndex;
    }

    public int getHighIndex() {
        return highIndex;
    }

    public void setHighIndex(int highIndex) {
        this.highIndex = highIndex;
    }

    public int getSum() {
        return sum;
    }

    public void setSum(int sum) {
        this.sum = sum;
    }
}
