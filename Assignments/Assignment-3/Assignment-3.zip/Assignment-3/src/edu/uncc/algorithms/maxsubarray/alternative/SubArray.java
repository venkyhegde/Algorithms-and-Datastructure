package edu.uncc.algorithms.maxsubarray.alternative;

/**
 * @author venky on 2019-02-19
 * @project Assignment-3
 * @package edu.uncc.algorithms.maxsubarray.alternative
 */

/**
 * POJO class to represent the sub array with required properties.
 */
public class SubArray {
    private int totalSum;
    private int maxSum;
    private int maxPrefix;
    private int maxSufix;

    public int getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(int totalSum) {
        this.totalSum = totalSum;
    }

    public int getMaxSum() {
        return maxSum;
    }

    public void setMaxSum(int maxSum) {
        this.maxSum = maxSum;
    }

    public int getMaxPrefix() {
        return maxPrefix;
    }

    public void setMaxPrefix(int maxPrefix) {
        this.maxPrefix = maxPrefix;
    }

    public int getMaxSufix() {
        return maxSufix;
    }

    public void setMaxSufix(int maxSufix) {
        this.maxSufix = maxSufix;
    }
}
