package edu.uncc.algorithms.maxsubarray.alternative;

/**
 * @author venky on 2019-02-21
 * @project Assignment-3
 * @package edu.uncc.algorithms.maxsubarray.alternative
 */
/**
 * this class provides methods which finds the maximum sum of sub array using alternative linear algorithm.
 */
public class MaximumSubArrayLinearTime {

    /**
     * Public static method to find maximum sum of sub array.
     *
     * @param array
     *         An input array of integers
     * @param low
     *         Staring index of input array
     * @param high
     *         last index of input array
     *
     * @return An instance of SubArray
     */
    public static SubArray fmsCompare(int[] array, int low, int high) {
        SubArray maxSubArray = new SubArray ();
        // checking for the base condition
        if ( low == high ) {
            maxSubArray.setTotalSum (array[low]);
            maxSubArray.setMaxSum (array[low]);
            maxSubArray.setMaxPrefix (array[low]);
            maxSubArray.setMaxSufix (array[low]);
            return maxSubArray;
        }

        int mid = (low + high) / 2;
        SubArray leftSubArray = fmsCompare (array, low, mid);
        SubArray rightSubArray = fmsCompare (array, mid + 1, high);

        return compare (array, leftSubArray, rightSubArray);
    }

    /**
     * Method to compare the left and right sub arrays to find maximum sum of sub array.
     *
     * @param array
     *         An input array of integers
     * @param leftSubArray
     *         Lest sub array
     * @param rightSubArray
     *         Right sub Array
     *
     * @return AN instance of SubArray
     */
    private static SubArray compare(int[] array, SubArray leftSubArray, SubArray rightSubArray) {

        SubArray maxSubArray = new SubArray ();
        maxSubArray.setTotalSum (leftSubArray.getTotalSum () + rightSubArray.getTotalSum ());
        maxSubArray.setMaxPrefix (
                Math.max (leftSubArray.getMaxPrefix (), (leftSubArray.getTotalSum () + rightSubArray.getMaxPrefix ())));
        maxSubArray.setMaxSufix (
                Math.max (rightSubArray.getMaxSufix (), (rightSubArray.getTotalSum () + leftSubArray.getMaxSufix ())));
        maxSubArray.setMaxSum (Math.max (Math.max (leftSubArray.getMaxSum (), rightSubArray.getMaxSum ()),
                (leftSubArray.getMaxSufix () + rightSubArray.getMaxPrefix ())));
        return maxSubArray;
    }
}
