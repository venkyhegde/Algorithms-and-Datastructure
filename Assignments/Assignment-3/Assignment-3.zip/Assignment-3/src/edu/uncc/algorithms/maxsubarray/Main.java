package edu.uncc.algorithms.maxsubarray;

import edu.uncc.algorithms.maxsubarray.alternative.MaximumSubArrayLinearTime;
import edu.uncc.algorithms.maxsubarray.divideandconq.MaximumSubArray;
import edu.uncc.algorithms.maxsubarray.divideandconq.SubArray;
/**
 * @author venky on 2019-02-21
 * @project Assignment-3
 * @package edu.uncc.algorithms.maxsubarray
 */


/**
 * Main class
 */
public class Main {

    public static void main(String[] args) {

        int[] givenArray = { 13, -3, -25, 20, -3, -16, -23, 18, 20, -7, 12, -5, -22, 15, -4, 7 };
        int[] baseCase;
        baseCase = new int[] { 1 };
        int[] testAverageCase = { -10, 2, 8, 4, 2, 1 };

        System.out.println ("Executing traditional Divide Conquer");
        System.out.println ("------------------------------------------");
        System.out.println ("Case 1 - Given array :");
        for ( int i : givenArray ) {
            System.out.print (i + " ");
        }
        System.out.println ();
        SubArray subArray = MaximumSubArray.findMaximumSubArray (givenArray, 0, givenArray.length - 1);
        System.out.println ("Maximum sum: " + subArray.getSum ());
        System.out.println (
                "Start index of sub array: " + subArray.getLowIndex () + " Last Index of sub array: " + subArray
                        .getHighIndex ());

        System.out.println ("\nCase 2 - Base condition :");
        for ( int i : baseCase ) {
            System.out.print (i + " ");
        }
        System.out.println ();
        subArray = MaximumSubArray.findMaximumSubArray (baseCase, 0, baseCase.length - 1);
        System.out.println ("Maximum sum: " + subArray.getSum ());
        System.out.println (
                "Start index of sub array: " + subArray.getLowIndex () + " Last Index of sub array: " + subArray
                        .getHighIndex ());

        System.out.println ("\nCase 3 - Random Array :");
        for ( int i : testAverageCase ) {
            System.out.print (i + " ");
        }
        System.out.println ();
        subArray = MaximumSubArray.findMaximumSubArray (testAverageCase, 0, testAverageCase.length - 1);
        System.out.println ("Maximum sum: " + subArray.getSum ());
        System.out.println (
                "Start index of sub array: " + subArray.getLowIndex () + " Last Index of sub array: " + subArray
                        .getHighIndex ());


        System.out.println ("\n\nExecuting Alternate Linear time solution");
        System.out.println ("------------------------------------------");
        System.out.println ("Case 1 - Given array :");
        for ( int i : givenArray ) {
            System.out.print (i + " ");
        }
        System.out.println ();
        edu.uncc.algorithms.maxsubarray.alternative.SubArray subArray1 = MaximumSubArrayLinearTime
                .fmsCompare (givenArray, 0, givenArray.length - 1);
        System.out.println ("Sum of maximum sub array is: "+ subArray1.getMaxSum ());

        System.out.println ("\nCase 2 - Base Condition :");
        for ( int i : baseCase ) {
            System.out.print (i + " ");
        }
        System.out.println ();
        subArray1 = MaximumSubArrayLinearTime
                .fmsCompare (baseCase, 0, baseCase.length - 1);
        System.out.println ("Sum of maximum sub array is: "+ subArray1.getMaxSum ());


        System.out.println ("\nCase 3 - Random Array :");
        for ( int i : testAverageCase ) {
            System.out.print (i + " ");
        }
        System.out.println ();
        subArray1 = MaximumSubArrayLinearTime
                .fmsCompare (testAverageCase, 0, testAverageCase.length - 1);
        System.out.println ("Sum of maximum sub array is: "+ subArray1.getMaxSum ());

    }
}
