package edu.uncc.algorithms.maxsubarray.divideandconq;

/**
 * @author venky on 2019-02-19
 * @project Assignment-3
 * @package edu.uncc.algorithms.maxsubarray.divideandconq
 */
/**
 * The class MaximumSubArray provides static method to find the maximum sum of a sub array in an Integer array.
 * The goal of finding maximum sub array is achieved using divide and conquer method by recursively calling
 * maximumSubArray method.
 */
public class MaximumSubArray {

    /**
     * A public static method to find the sub array which gives maximum sum in an array.
     *
     * @param array
     *         An input array of integers
     * @param low
     *         start index of input array
     * @param high
     *         last index of input array
     *
     * @return an instance of SubArray.
     */
    public static SubArray findMaximumSubArray(int[] array, int low, int high) {
        SubArray subArray = new SubArray ();
        // checking for base case, if there only one element.
        if ( high == low ) {
            subArray.setLowIndex (low);
            subArray.setHighIndex (high);
            subArray.setSum (array[low]);
            return subArray;
        }
        int mid = (low + high) / 2; // finding the middle element of array

        SubArray leftSubArray = findMaximumSubArray (array, low, mid);
        SubArray rightSubArray = findMaximumSubArray (array, mid + 1, high);
        SubArray crossingSubArray = findMaxCrossingSubArray (array, low, mid, high);

        if ( leftSubArray.getSum () >= rightSubArray.getSum () && leftSubArray.getSum () >= crossingSubArray
                .getSum () ) {
            return leftSubArray;
        } else if ( rightSubArray.getSum () >= leftSubArray.getSum () && rightSubArray.getSum () >= crossingSubArray
                .getSum () ) {
            return rightSubArray;
        } else {
            return crossingSubArray;
        }

    }

    /**
     * A private static method to find the maximum sub array across middle
     *
     * @param array
     *         An input array of integers
     * @param low
     *         first index of input array
     * @param mid
     *         middle index of input array
     * @param high
     *         last index of input array
     *
     * @return an instance of SubArray
     */
    private static SubArray findMaxCrossingSubArray(int[] array, int low, int mid, int high) {

        int leftSum = Integer.MIN_VALUE;
        int maxLeft = 0;
        int sum = 0;

        for ( int i = mid ; i >= low ; i-- ) {
            sum += array[i];
            if ( sum > leftSum ) {
                leftSum = sum;
                maxLeft = i;
            }
        }

        int rightSum = Integer.MIN_VALUE;
        int maxRight = 0;
        sum = 0;

        for ( int j = mid + 1 ; j <= high ; j++ ) {
            sum += array[j];
            if ( sum > rightSum ) {
                rightSum = sum;
                maxRight = j;
            }
        }

        SubArray crossingSubArray = new SubArray ();
        crossingSubArray.setLowIndex (maxLeft);
        crossingSubArray.setHighIndex (maxRight);
        crossingSubArray.setSum ((leftSum + rightSum));

        return crossingSubArray;
    }
}
