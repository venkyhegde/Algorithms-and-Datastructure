package edu.uncc.algorithms.maxsubarray.divideandconq;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * @author venky on 2019-02-21
 * @project Assignment-3
 * @package edu.uncc.algorithms.maxsubarray.divideandconq
 */
public class MaximumSubArrayTest {

    @Test
    public void findMaximumSubArray() {

        int[] givenArray = { 13, -3, -25, 20, -3, -16, -23, 18, 20, -7, 12, -5, -22, 15, -4, 7 };
        int[] baseCase = { 1 };
        int[] testAverageCase = { -10, 2, 8, 4, 2, 1 };

        // testing for given array
        SubArray maxSubArry = MaximumSubArray.findMaximumSubArray (givenArray,0, givenArray.length-1);
        Assert.assertEquals (43, maxSubArry.getSum ()); // testing for sum
        Assert.assertEquals (7, maxSubArry.getLowIndex ()); // testing for start index of sub array
        Assert.assertEquals (10, maxSubArry.getHighIndex ()); //testing for last index of sub array

        //testing for base case
        maxSubArry = MaximumSubArray.findMaximumSubArray (baseCase,0,baseCase.length-1);
        Assert.assertEquals (1, maxSubArry.getSum ()); // testing for sum
        Assert.assertEquals (0, maxSubArry.getLowIndex ()); // testing for start index of sub array
        Assert.assertEquals (0, maxSubArry.getHighIndex ()); //testing for last index of sub array

        //testing for rondom array
        maxSubArry = MaximumSubArray.findMaximumSubArray (testAverageCase,0, testAverageCase.length-1);
        Assert.assertEquals (17, maxSubArry.getSum ()); // testing for sum
        Assert.assertEquals (1, maxSubArry.getLowIndex ()); // testing for start index of sub array
        Assert.assertEquals (5, maxSubArry.getHighIndex ()); //testing for last index of sub array

    }
}